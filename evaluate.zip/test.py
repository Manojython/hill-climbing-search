from test_files import test
test.test_all()
print("Test cases passed")
